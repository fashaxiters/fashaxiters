import React, { useState } from 'react';
import {
  TabType,
  GameType,
  CategoryType,
  AimFeatures,
  VisualFeatures,
  ExploitState,
  UserAccount,
  LanguageType,
} from './types';
import { IosBottomBar } from './components/IosBottomBar';
import { ExploitView } from './components/ExploitView';
import { AccountView } from './components/AccountView';
import { LoginView } from './components/LoginView';
import { getT } from './utils/translations';

export default function App() {
  // Authentication state - Starts on Login page as requested
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);

  // Navigation tab state: Exploit or Account (No Exploit removed as requested)
  const [currentTab, setCurrentTab] = useState<TabType>('Exploit');

  // Game selection: Free Fire vs Free Fire MAX
  const [game, setGame] = useState<GameType>('Free Fire');

  // Category selection: Aim vs Visuals
  const [category, setCategory] = useState<CategoryType>('Aim');

  // Aim feature toggles with requested text mappings
  const [aim, setAim] = useState<AimFeatures>({
    drag: false, // Drag Hs Patch
    body100: false, // Dynamic Sensitivity
    body95: false, // Recoil Controller
    maggicBullet: false, // Sensitivity X 75/ Y 75
    modChest: false, // Kecepatan Layar 120
  });

  // Visual feature toggles with Resolusi 400 x 2440 and Pixel Per Inch 450
  const [visuals, setVisuals] = useState<VisualFeatures>({
    resolution400x2440: false,
    pixelPerInch450: false,
  });

  // Account profile state with language support (default ID)
  const [account, setAccount] = useState<UserAccount>({
    userId: '162091',
    vipStatus: 'Lifetime',
    expiration: 'Lifetime',
    deviceModel: 'Device: 162091',
    language: 'id',
  });

  const t = getT(account.language);

  // Exploit execution state
  const [exploitState, setExploitState] = useState<ExploitState>({
    isStarted: false,
    statusText: t.exploit.statusNotStarted,
    subStatusText: t.exploit.subStatusNotStarted,
    progress: 0,
    memoryInjected: false,
    bypassActive: false,
    logs: [
      '[Status] Ready for target selection. Sandbox active.',
      '[Memory] Awaiting user trigger...',
    ],
  });

  const handleLanguageChange = (newLang: LanguageType) => {
    setAccount((prev) => ({ ...prev, language: newLang }));
    const newT = getT(newLang);
    setExploitState((prev) => ({
      ...prev,
      statusText: prev.isStarted ? newT.exploit.statusRunning : newT.exploit.statusNotStarted,
      subStatusText: prev.isStarted ? newT.exploit.subStatusRunning : newT.exploit.subStatusNotStarted,
    }));
  };

  const handleReset = () => {
    setAim({
      drag: false,
      body100: false,
      body95: false,
      maggicBullet: false,
      modChest: false,
    });
    setVisuals({
      resolution400x2440: false,
      pixelPerInch450: false,
    });
  };

  const handleLoginSuccess = (deviceId: string) => {
    setAccount((prev) => ({
      ...prev,
      userId: deviceId,
    }));
    setIsAuthenticated(true);
    setCurrentTab('Exploit');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentTab('Exploit');
    const currentT = getT(account.language);
    setExploitState({
      isStarted: false,
      statusText: currentT.exploit.statusNotStarted,
      subStatusText: currentT.exploit.subStatusNotStarted,
      progress: 0,
      memoryInjected: false,
      bypassActive: false,
      logs: ['[System] Logged out. Sandbox locked.'],
    });
  };

  return (
    <div className="h-[100dvh] max-h-[100dvh] overflow-hidden bg-[#f2f2f6] text-gray-900 font-sans flex flex-col justify-between max-w-md mx-auto relative shadow-sm">
      {/* Scrollable Main Screen Content - scrolls independently while taskbar stays static */}
      <main
        id="app-main-content"
        className="flex-1 overflow-y-auto px-5 pt-4 pb-4 scrollbar-none flex flex-col"
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        {!isAuthenticated ? (
          <LoginView
            onLoginSuccess={handleLoginSuccess}
            language={account.language}
          />
        ) : (
          <>
            {currentTab === 'Exploit' && (
              <ExploitView
                game={game}
                setGame={setGame}
                category={category}
                setCategory={setCategory}
                aim={aim}
                setAim={setAim}
                visuals={visuals}
                setVisuals={setVisuals}
                onReset={handleReset}
                exploitState={exploitState}
                setExploitState={setExploitState}
                language={account.language}
              />
            )}

            {currentTab === 'Account' && (
              <AccountView
                account={account}
                onLogout={handleLogout}
                onLanguageChange={handleLanguageChange}
              />
            )}
          </>
        )}
      </main>

      {/* iOS Bottom Navigation Bar - Fixed & never scrolls with content */}
      {isAuthenticated && (
        <IosBottomBar
          currentTab={currentTab}
          onTabChange={(tab) => {
            setCurrentTab(tab);
          }}
          language={account.language}
        />
      )}
    </div>
  );
}
