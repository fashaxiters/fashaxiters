export type TabType = 'Exploit' | 'Account';

export type GameType = 'Free Fire' | 'Free Fire MAX';

export type CategoryType = 'Aim' | 'Visuals';

export type LanguageType = 'id' | 'en';

export interface AimFeatures {
  drag: boolean; // Drag Hs Patch
  body100: boolean; // Dynamic Sensitivity
  body95: boolean; // Recoil Controller
  maggicBullet: boolean; // Sensitivity X 75/ Y 75
  modChest: boolean; // Kecepatan Layar 120
}

export interface VisualFeatures {
  resolution400x2440: boolean; // Resolusi 400 x 2440
  pixelPerInch450: boolean; // Pixel Per Inch 450
}

export interface ExploitState {
  isStarted: boolean;
  statusText: string;
  subStatusText: string;
  progress: number;
  memoryInjected: boolean;
  bypassActive: boolean;
  logs: string[];
}

export interface UserAccount {
  userId: string;
  vipStatus: string;
  expiration: string;
  deviceModel: string;
  language: LanguageType;
}
