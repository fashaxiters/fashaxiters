import React, { useState } from 'react';
import { LogIn, ShieldAlert } from 'lucide-react';
import { LanguageType } from '../types';
import { getT } from '../utils/translations';

interface LoginViewProps {
  onLoginSuccess: (deviceId: string) => void;
  language: LanguageType;
}

export const LoginView: React.FC<LoginViewProps> = ({
  onLoginSuccess,
  language,
}) => {
  const [inputKey, setInputKey] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const t = getT(language);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = inputKey.trim();

    if (!trimmed) {
      setErrorMessage(t.login.errorEmpty);
      return;
    }

    if (trimmed !== '162091') {
      setErrorMessage(t.login.errorInvalid);
      return;
    }

    onLoginSuccess(trimmed);
  };

  return (
    <div id="view-login" className="w-full flex flex-col justify-center items-center min-h-[75vh] px-2 relative">
      <div className="w-full bg-white rounded-3xl p-6 shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-gray-100/80 space-y-5">
        {/* Header Icon & Title */}
        <div className="text-center space-y-2.5">
          <div className="w-20 h-20 mx-auto rounded-2xl overflow-hidden shadow-[0_4px_12px_rgba(0,0,0,0.08)] border border-gray-100/80">
            <img
              src="/freefire-icon.png"
              alt="Free Fire Icon"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <h2 className="text-[19px] font-bold text-gray-900 tracking-tight">
              {t.appTitle}
            </h2>
            <p className="text-[12px] text-gray-500 font-medium tracking-tight mt-0.5">
              Web App Settings FreeFire - iOS
            </p>
          </div>
        </div>

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[13px] font-medium text-gray-700 mb-1.5">
              {t.login.deviceIdLabel}
            </label>
            <input
              type="text"
              autoFocus
              placeholder={t.login.placeholder}
              value={inputKey}
              onChange={(e) => {
                setInputKey(e.target.value);
                setErrorMessage('');
              }}
              className="w-full bg-gray-50 border border-gray-200 px-3.5 py-3 rounded-xl text-[15px] text-gray-900 focus:outline-none focus:border-blue-500 transition-colors"
            />
            {errorMessage && (
              <div className="flex items-center gap-1.5 text-[12px] text-red-500 mt-2">
                <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}
          </div>

          <button
            type="submit"
            className="w-full bg-[#007aff] hover:bg-[#0062cc] active:scale-[0.99] text-white font-semibold text-[15px] py-3 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
          >
            <LogIn className="w-4 h-4" />
            <span>{t.login.submit}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
