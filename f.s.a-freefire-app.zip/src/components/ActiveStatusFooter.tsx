import React from 'react';
import { GameType, AimFeatures, VisualFeatures, LanguageType } from '../types';
import { getT } from '../utils/translations';

interface ActiveStatusFooterProps {
  game: GameType;
  aim: AimFeatures;
  visuals: VisualFeatures;
  language: LanguageType;
}

export const ActiveStatusFooter: React.FC<ActiveStatusFooterProps> = ({
  game,
  aim,
  visuals,
  language,
}) => {
  const t = getT(language);
  const activeList: string[] = [];

  if (aim.drag) activeList.push(t.exploit.aimFeatures.drag.title);
  if (aim.body100) activeList.push(t.exploit.aimFeatures.body100.title);
  if (aim.body95) activeList.push(t.exploit.aimFeatures.body95.title);
  if (aim.maggicBullet) activeList.push(t.exploit.aimFeatures.maggicBullet.title);
  if (aim.modChest) activeList.push(t.exploit.aimFeatures.modChest.title);

  if (visuals.resolution400x2440) activeList.push(t.exploit.visualFeatures.resolution.title);
  if (visuals.pixelPerInch450) activeList.push(t.exploit.visualFeatures.ppi.title);

  return (
    <div id="active-status-footer" className="mt-4 px-1 select-none text-left">
      <p className="text-[13px] text-gray-700 font-normal leading-relaxed">
        {game}
      </p>
      <p className="text-[13px] text-gray-600 font-normal leading-relaxed">
        {activeList.length === 0 ? (
          t.exploit.footerSelect
        ) : (
          <span>
            {t.exploit.footerActive}{' '}
            <span className="text-gray-900 font-medium">{activeList.join(', ')}</span>
          </span>
        )}
      </p>
    </div>
  );
};
