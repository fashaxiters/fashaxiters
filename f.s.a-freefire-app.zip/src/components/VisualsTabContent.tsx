import React from 'react';
import { VisualFeatures, LanguageType } from '../types';
import { IosSwitch } from './IosSwitch';
import { getT } from '../utils/translations';

interface VisualsTabContentProps {
  features: VisualFeatures;
  onChange: (key: keyof VisualFeatures, value: boolean) => void;
  language: LanguageType;
}

export const VisualsTabContent: React.FC<VisualsTabContentProps> = ({
  features,
  onChange,
  language,
}) => {
  const t = getT(language);

  return (
    <div id="visuals-features-list" className="space-y-2.5">
      {/* Fitur Resolusi 400 x 2440 */}
      <div
        id="item-resolusi-400x2440"
        className="bg-white rounded-2xl px-4 py-3.5 flex items-center justify-between shadow-[0_1px_3px_rgba(0,0,0,0.03)] border border-gray-100/70 transition-all active:scale-[0.99]"
      >
        <div className="flex-1 pr-3">
          <span className="text-[15px] text-black font-semibold tracking-tight block leading-snug">
            {t.exploit.visualFeatures.resolution.title}
          </span>
        </div>
        <IosSwitch
          id="switch-resolusi-400x2440"
          checked={features.resolution400x2440}
          onChange={(val) => onChange('resolution400x2440', val)}
        />
      </div>

      {/* Fitur Pixel Per Inch 450 */}
      <div
        id="item-pixel-per-inch-450"
        className="bg-white rounded-2xl px-4 py-3.5 flex items-center justify-between shadow-[0_1px_3px_rgba(0,0,0,0.03)] border border-gray-100/70 transition-all active:scale-[0.99]"
      >
        <div className="flex-1 pr-3">
          <span className="text-[15px] text-black font-semibold tracking-tight block leading-snug">
            {t.exploit.visualFeatures.ppi.title}
          </span>
        </div>
        <IosSwitch
          id="switch-pixel-per-inch-450"
          checked={features.pixelPerInch450}
          onChange={(val) => onChange('pixelPerInch450', val)}
        />
      </div>
    </div>
  );
};
