import React from 'react';

interface SegmentedControlProps<T extends string> {
  id?: string;
  options: { label: string; value: T }[];
  value: T;
  onChange: (value: T) => void;
}

export function SegmentedControl<T extends string>({
  id,
  options,
  value,
  onChange,
}: SegmentedControlProps<T>) {
  return (
    <div
      id={id}
      className="w-full bg-[#e3e4e8] p-1 rounded-xl flex items-center shadow-inner select-none transition-all"
    >
      {options.map((option) => {
        const isActive = option.value === value;
        return (
          <button
            key={option.value}
            type="button"
            onClick={() => onChange(option.value)}
            className={`flex-1 py-1.5 px-3 text-center text-[14px] leading-tight rounded-lg transition-all duration-200 cursor-pointer ${
              isActive
                ? 'bg-white text-black font-bold shadow-xs'
                : 'text-gray-700 font-medium hover:text-black'
            }`}
          >
            {option.label}
          </button>
        );
      })}
    </div>
  );
}
