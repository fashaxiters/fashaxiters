import React from 'react';
import { AimFeatures, LanguageType } from '../types';
import { IosSwitch } from './IosSwitch';
import { getT } from '../utils/translations';

interface AimTabContentProps {
  features: AimFeatures;
  onChange: (key: keyof AimFeatures, value: boolean) => void;
  language: LanguageType;
}

export const AimTabContent: React.FC<AimTabContentProps> = ({
  features,
  onChange,
  language,
}) => {
  const t = getT(language);

  const aimItems: {
    key: keyof AimFeatures;
    label: string;
  }[] = [
    {
      key: 'drag',
      label: t.exploit.aimFeatures.drag.title,
    },
    {
      key: 'body100',
      label: t.exploit.aimFeatures.body100.title,
    },
    {
      key: 'body95',
      label: t.exploit.aimFeatures.body95.title,
    },
    {
      key: 'maggicBullet',
      label: t.exploit.aimFeatures.maggicBullet.title,
    },
    {
      key: 'modChest',
      label: t.exploit.aimFeatures.modChest.title,
    },
  ];

  const handleToggle = (key: keyof AimFeatures, nextVal: boolean) => {
    // If switching between Dynamic Sensitivity and Recoil Controller, keep them clean
    if (key === 'body100' && nextVal && features.body95) {
      onChange('body95', false);
    } else if (key === 'body95' && nextVal && features.body100) {
      onChange('body100', false);
    }
    onChange(key, nextVal);
  };

  return (
    <div id="aim-features-list" className="space-y-2.5">
      {aimItems.map((item) => {
        const isChecked = features[item.key];
        return (
          <div
            key={item.key}
            id={`item-${item.key}`}
            className="bg-white rounded-2xl px-4 py-3.5 flex items-center justify-between shadow-[0_1px_3px_rgba(0,0,0,0.03)] border border-gray-100/70 transition-all active:scale-[0.99]"
          >
            <div className="flex-1 pr-3">
              <span className="text-[15px] text-black font-semibold tracking-tight block leading-snug">
                {item.label}
              </span>
            </div>
            <IosSwitch
              id={`switch-${item.key}`}
              checked={isChecked}
              onChange={(val) => handleToggle(item.key, val)}
            />
          </div>
        );
      })}
    </div>
  );
};
