import React, { useState } from 'react';
import { UserAccount, GameType, LanguageType } from '../types';
import {
  ShieldCheck,
  Key,
  LogOut,
  Globe,
  Copy,
  Check,
  Cpu,
  Code2,
  Phone,
} from 'lucide-react';
import { getT } from '../utils/translations';

interface AccountViewProps {
  account: UserAccount;
  onLogout: () => void;
  onLanguageChange?: (lang: LanguageType) => void;
}

export const AccountView: React.FC<AccountViewProps> = ({
  account,
  onLogout,
  onLanguageChange,
}) => {
  const licenseKey = account.userId || '162091';
  const [copied, setCopied] = useState(false);

  const t = getT(account.language);

  const handleCopyKey = async () => {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(licenseKey);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = licenseKey;
        textArea.style.position = 'fixed';
        textArea.style.opacity = '0';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // fallback
    }
  };

  return (
    <div id="view-account" className="w-full flex flex-col space-y-4">
      {/* Title */}
      <div className="text-center pt-2 pb-1">
        <h1 className="text-[19px] font-bold text-black tracking-tight">
          {t.account.title}
        </h1>
      </div>

      {/* User Profile Card */}
      <div className="bg-white rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-gray-100/80">
        <div className="flex items-center space-x-3 pb-3 border-b border-gray-100">
          <div className="w-12 h-12 rounded-xl overflow-hidden shadow-xs border border-gray-100 flex-shrink-0">
            <img
              src="/freefire-icon.png"
              alt="Free Fire Avatar"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="flex-1">
            <p className="text-[14px] text-gray-900 font-semibold">
              {t.account.licenseLabel}{' '}
              <span className="text-emerald-500 font-bold">{t.account.licenseLifetime}</span>
            </p>
            <p className="text-[12px] text-gray-500 font-medium mt-0.5">
              {t.account.singleDeviceNote}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 pt-3 text-[12px]">
          <div className="bg-gray-50 p-2.5 rounded-xl">
            <span className="text-gray-400 block text-[11px] font-medium">
              {t.account.apiKeyLabel}
            </span>
            <span className="font-semibold text-gray-800 flex items-center gap-1.5 mt-0.5 font-mono text-[13px]">
              <Cpu className="w-3.5 h-3.5 text-blue-500 shrink-0" />
              {t.account.apiKeyValue}
            </span>
          </div>
          <div className="bg-gray-50 p-2.5 rounded-xl">
            <span className="text-gray-400 block text-[11px] font-medium">
              {t.account.bypassStatusLabel}
            </span>
            <span className="font-semibold text-emerald-600 flex items-center gap-1 mt-0.5 text-[11.5px] leading-tight">
              <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
              {t.account.bypassStatusValue}
            </span>
          </div>
        </div>
      </div>

      {/* License verification Card with Copy Action */}
      <div className="bg-white rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-gray-100/80 space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-[14px] font-semibold text-gray-800">
            <Key className="w-4 h-4 text-amber-500" />
            <span>{t.account.activeLicenseLabel}</span>
          </div>
          {copied && (
            <span className="text-[11px] text-emerald-600 font-medium flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-md">
              <Check className="w-3 h-3" /> {t.account.copiedTooltip}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <input
            type="text"
            readOnly
            value={licenseKey}
            className="flex-1 bg-gray-50 border border-gray-200 px-3 py-2 rounded-lg text-[13px] font-mono font-medium text-gray-800 select-all tracking-wider"
          />
          <button
            id="btn-copy-license-key"
            type="button"
            onClick={handleCopyKey}
            className={`px-3.5 py-2 rounded-lg text-[12px] font-medium transition-all cursor-pointer flex items-center gap-1.5 active:scale-95 ${
              copied
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-blue-50 text-blue-600 hover:bg-blue-100 border border-blue-100'
            }`}
            title={t.account.copyButton}
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>{t.account.copiedTooltip}</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>{t.account.copyButton}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Language Selector / Fitur Bahasa (English / Indonesia) */}
      <div
        id="card-language-selector"
        className="bg-white rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-gray-100/80 space-y-3"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-[14px] font-semibold text-gray-900">
            <Globe className="w-4 h-4 text-blue-600" />
            <span>{t.account.languageLabel}</span>
          </div>
          <span className="text-[11px] font-medium text-gray-400">
            {t.account.languageSubtitle}
          </span>
        </div>

        {/* iOS-Style Segmented Buttons */}
        <div className="bg-gray-100/90 p-1 rounded-xl flex items-center gap-1">
          <button
            id="btn-lang-en"
            type="button"
            onClick={() => onLanguageChange?.('en')}
            className={`flex-1 py-2 px-3 rounded-lg text-[13px] font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer ${
              account.language === 'en'
                ? 'bg-white text-blue-600 shadow-sm'
                : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            <span className="text-base">🇬🇧</span>
            <span>English</span>
          </button>
          <button
            id="btn-lang-id"
            type="button"
            onClick={() => onLanguageChange?.('id')}
            className={`flex-1 py-2 px-3 rounded-lg text-[13px] font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer ${
              account.language === 'id'
                ? 'bg-white text-blue-600 shadow-sm'
                : 'text-gray-500 hover:text-gray-800'
            }`}
          >
            <span className="text-base">🇮🇩</span>
            <span>Indonesia</span>
          </button>
        </div>
      </div>

      {/* Developer Information Card */}
      <div
        id="card-developer-info"
        className="bg-white rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-gray-100/80 space-y-3"
      >
        <div className="flex items-center justify-between pb-2 border-b border-gray-100">
          <div className="flex items-center gap-2 text-[14px] font-semibold text-gray-900">
            <Code2 className="w-4 h-4 text-blue-600" />
            <span>Developer</span>
          </div>
          <span className="text-[13px] font-bold text-gray-800 tracking-tight">
            Fsha.Xploit
          </span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-[14px] font-medium text-gray-700">
            <Phone className="w-4 h-4 text-emerald-600" />
            <span>WhatsApp</span>
          </div>
          <a
            id="link-developer-whatsapp"
            href="https://wa.me/6283171245342"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[13px] font-semibold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 transition-colors"
          >
            0831-7124-5342
          </a>
        </div>
      </div>

      {/* Tombol Logout */}
      <div className="pt-1">
        <button
          id="btn-account-logout"
          type="button"
          onClick={onLogout}
          className="w-full bg-red-50 hover:bg-red-100 text-red-600 font-semibold text-[15px] py-3 rounded-2xl transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-[0.99] border border-red-100"
        >
          <LogOut className="w-4 h-4" />
          <span>{t.account.logout}</span>
        </button>
      </div>
    </div>
  );
};
