import React from 'react';
import { Crosshair, User } from 'lucide-react';
import { TabType, LanguageType } from '../types';
import { getT } from '../utils/translations';

interface IosBottomBarProps {
  currentTab: TabType;
  onTabChange: (tab: TabType) => void;
  language?: LanguageType;
}

export const IosBottomBar: React.FC<IosBottomBarProps> = ({
  currentTab,
  onTabChange,
  language = 'id',
}) => {
  const t = getT(language);

  const tabs: { id: TabType; label: string; icon: React.ReactNode }[] = [
    {
      id: 'Exploit',
      label: t.nav.exploit,
      icon: <Crosshair className="w-5 h-5" strokeWidth={currentTab === 'Exploit' ? 2.3 : 1.7} />,
    },
    {
      id: 'Account',
      label: t.nav.account,
      icon: <User className="w-5 h-5" strokeWidth={currentTab === 'Account' ? 2.3 : 1.7} />,
    },
  ];

  return (
    <nav
      id="ios-bottom-nav"
      className="w-full bg-[#f8f8f9]/95 backdrop-blur-lg border-t border-gray-200/80 px-8 py-2.5 pb-6 flex items-center justify-around select-none shrink-0 shadow-[0_-2px_10px_rgba(0,0,0,0.03)] z-40"
    >
      {tabs.map((tab) => {
        const isActive = currentTab === tab.id;
        return (
          <button
            key={tab.id}
            id={`tab-${tab.id.toLowerCase().replace(/\s+/g, '-')}`}
            type="button"
            onClick={() => onTabChange(tab.id)}
            className={`flex flex-col items-center justify-center space-y-1 transition-all py-1 px-6 rounded-xl cursor-pointer ${
              isActive ? 'text-blue-600 font-semibold scale-105' : 'text-[#8e8e93] hover:text-gray-700 font-normal'
            }`}
          >
            <div className="flex items-center justify-center">
              {tab.icon}
            </div>
            <span className="text-[11px] leading-tight tracking-tight font-medium">
              {tab.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
