import { LanguageType } from '../types';

export const translations = {
  id: {
    appTitle: 'F.S.A FreeFire App',
    login: {
      deviceIdLabel: 'Acces key',
      placeholder: '',
      submit: 'Masuk',
      errorEmpty: 'Silakan masukkan Acces key',
      errorInvalid: 'Acces key tidak valid atau tidak terdaftar',
    },
    nav: {
      exploit: 'Exploit',
      account: 'Akun',
    },
    exploit: {
      title: 'Exploit',
      statusNotStarted: 'Exploit: belum dimulai',
      subStatusNotStarted: 'sandbox terkunci',
      statusRunning: 'Exploit: berjalan',
      subStatusRunning: 'sandbox ter-bypass & aktif',
      btnInjecting: 'MELUNCURKAN & MENGINJEKSI...',
      btnStop: 'HENTIKAN EXPLOIT',
      btnStart: 'MULAI',
      catAim: 'Bidikan',
      catVisuals: 'Visual',
      btnReset: 'Atur Ulang',
      footerSelect: 'Pilih opsi di atas',
      footerActive: 'Aktif:',
      aimFeatures: {
        drag: {
          title: 'Drag Hs Patch',
        },
        body100: {
          title: 'Dynamic Sensitivity',
        },
        body95: {
          title: 'Recoil Controller',
        },
        maggicBullet: {
          title: 'Sensitivity X 75/ Y 75',
        },
        modChest: {
          title: 'Kecepatan Layar 120',
        },
      },
      visualFeatures: {
        resolution: {
          title: 'Resolusi 400 x 2440',
        },
        ppi: {
          title: 'Pixel Per Inch 450',
        },
      },
    },
    account: {
      title: 'Akun',
      licenseLabel: 'Lisensi:',
      licenseLifetime: 'Lifetime',
      singleDeviceNote: 'Hanya bisa digunakan 1 device: 162091',
      apiKeyLabel: 'API Key',
      apiKeyValue: 'FSA-0092846110',
      bypassStatusLabel: 'Status Bypass',
      bypassStatusValue: 'Bypass Security Active',
      activeLicenseLabel: 'ID Lisensi Aktif',
      copiedTooltip: 'Tersalin!',
      copyButton: 'Salin',
      languageLabel: 'Pilihan Bahasa',
      languageSubtitle: 'Indonesia / English',
      logout: 'Keluar',
    },
  },
  en: {
    appTitle: 'F.S.A FreeFire App',
    login: {
      deviceIdLabel: 'Acces key',
      placeholder: '',
      submit: 'Log In',
      errorEmpty: 'Please enter Acces key',
      errorInvalid: 'Invalid or unregistered Acces key',
    },
    nav: {
      exploit: 'Exploit',
      account: 'Account',
    },
    exploit: {
      title: 'Exploit',
      statusNotStarted: 'Exploit: not started',
      subStatusNotStarted: 'sandbox locked',
      statusRunning: 'Exploit: running',
      subStatusRunning: 'sandbox bypassed & active',
      btnInjecting: 'LAUNCHING & INJECTING...',
      btnStop: 'STOP EXPLOIT',
      btnStart: 'START',
      catAim: 'Aim',
      catVisuals: 'Visuals',
      btnReset: 'Reset',
      footerSelect: 'Select an option above',
      footerActive: 'Active:',
      aimFeatures: {
        drag: {
          title: 'Drag Hs Patch',
        },
        body100: {
          title: 'Dynamic Sensitivity',
        },
        body95: {
          title: 'Recoil Controller',
        },
        maggicBullet: {
          title: 'Sensitivity X 75/ Y 75',
        },
        modChest: {
          title: 'Screen Speed 120',
        },
      },
      visualFeatures: {
        resolution: {
          title: 'Resolution 400 x 2440',
        },
        ppi: {
          title: 'Pixel Per Inch 450',
        },
      },
    },
    account: {
      title: 'Account',
      licenseLabel: 'License:',
      licenseLifetime: 'Lifetime',
      singleDeviceNote: 'Only for 1 device: 162091',
      apiKeyLabel: 'API Key',
      apiKeyValue: 'FSA-0092846110',
      bypassStatusLabel: 'Bypass Status',
      bypassStatusValue: 'Bypass Security Active',
      activeLicenseLabel: 'Active License ID',
      copiedTooltip: 'Copied!',
      copyButton: 'Copy',
      languageLabel: 'Language',
      languageSubtitle: 'English / Indonesia',
      logout: 'Log Out',
    },
  },
};

export const getT = (lang: LanguageType) => translations[lang] || translations.id;
